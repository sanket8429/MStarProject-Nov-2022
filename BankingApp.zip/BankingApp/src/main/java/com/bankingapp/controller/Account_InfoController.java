package com.bankingapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bankingapp.entity.Account_Info;
import com.bankingapp.service.Account_InfoService;

@RestController
@RequestMapping("/account_infoController")
public class Account_InfoController {
	
	@Autowired
	private Account_InfoService account_InfoService;
	
	private static Logger logger = LoggerFactory.getLogger(Account_InfoController	.class);
	
	@GetMapping(value="/getAllAccountInfo")
	public ResponseEntity<List<Account_Info>> getAllAccount_Infos() {
		
		List<Account_Info> list = account_InfoService.getAllAccount_Infos();
		return new ResponseEntity<List<Account_Info>>(list, HttpStatus.OK);
	}

	
	@GetMapping(value="/getAccount_InfoById/{user_id}")
	public ResponseEntity<Account_Info>  getAccount_InfoById(@PathVariable int user_id) {
		
		Account_Info reg = account_InfoService.getAccount_Info(user_id);
		return new ResponseEntity<Account_Info>(reg, HttpStatus.OK);
	}
	@PostMapping(value="/saveAccount_Info", consumes= {MediaType.APPLICATION_JSON_VALUE},
			produces= {MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Account_Info saveAccount_Info(@RequestBody  Account_Info registration) {
		
		account_InfoService.createAccount_Info(registration);
		return registration;
	}
	
	@PutMapping(value="/updateAccount_Info")
	public ResponseEntity<String> updateAccount_Info(@RequestBody Account_Info registration){
		
		account_InfoService.updateAccount_Info(registration);
		String string = "Updated Successfully";
		return new ResponseEntity<String>(string, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/deleteAccount_Info/{user_id}")
	public ResponseEntity<String> deleteAccount_Info(@PathVariable int user_id){
		account_InfoService.deleteAccount_Info(user_id);
		String string = "Deleted Successfully";
		return new ResponseEntity<String>(string, HttpStatus.OK);
		
	}
	

}
