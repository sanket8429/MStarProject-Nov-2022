package com.bankingapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bankingapp.entity.Transaction;
import com.bankingapp.service.TransactionService;
import com.bankingapp.service.TransactionService;

@RestController
@RequestMapping("/transactionController")
public class TransactionController {
	
	@Autowired
	private TransactionService transactionService;
	
	@GetMapping(value="/getAllTransactions")
	public ResponseEntity<List<Transaction>> getAllTransactions() {
		
		List<Transaction> list = transactionService.getAllTransactions();
		return new ResponseEntity<List<Transaction>>(list, HttpStatus.OK);
	}

	
	@GetMapping(value="/getTransactionById/{user_id}")
	public ResponseEntity<Transaction>  getTransactionById(@PathVariable int user_id) {
		
		Transaction reg = transactionService.getTransaction(user_id);
		return new ResponseEntity<Transaction>(reg, HttpStatus.OK);
	}
	@PostMapping(value="/saveTransaction", consumes= {MediaType.APPLICATION_JSON_VALUE},
			produces= {MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Transaction saveTransaction(@RequestBody  Transaction registration) {
		
		transactionService.createTransaction(registration);
		return registration;
	}
	
	@PutMapping(value="/updateTransaction")
	public ResponseEntity<String> updateTransaction(@RequestBody Transaction registration){
		
		transactionService.updateTransaction(registration);
		String string = "Updated Successfully";
		return new ResponseEntity<String>(string, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/deleteTransaction/{user_id}")
	public ResponseEntity<String> deleteTransaction(@PathVariable int user_id){
		transactionService.deleteTransaction(user_id);
		String string = "Deleted Successfully";
		return new ResponseEntity<String>(string, HttpStatus.OK);
		
	}
	
	@PostMapping(value="/debit")
	public ResponseEntity<String> debit(@RequestBody int acc_no, @RequestBody double amount){
		
		transactionService.debit(acc_no, amount);
		String string = "Debited Successfully";
		return new ResponseEntity<String>(string, HttpStatus.OK);
	}
	
	@GetMapping(value="/credit")
	public ResponseEntity<String> credit(@RequestParam ("account_no")long acc_no,@RequestParam("amount")double amount, @RequestParam("tx_type")String tx_type){
		
		transactionService.credit(acc_no, amount, tx_type);
		String string = "Credited Successfully";
		return new ResponseEntity<String>(string, HttpStatus.OK);
	}

}
