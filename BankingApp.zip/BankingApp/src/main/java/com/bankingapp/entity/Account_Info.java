package com.bankingapp.entity;

import java.util.List;

import com.bankingapp.constants.Account_type;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="account_info")
public class Account_Info {
	
	@Id
	@Column(name="Account_Number")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long account_no;
//	@Column(name="Account_Type", nullable=false)
//	private Account_type account_type;
	@Column(nullable=false)
	private String account_type;
	@Column(nullable=false)
	private double balance;
	
	@OneToMany
	@JoinColumn(name="account_no")
	private List<Transaction> transactions;

	public Account_Info() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account_Info(long account_no, String account_type, double balance) {
		super();
		this.account_no = account_no;
		this.account_type = account_type;
		this.balance = balance;
	}

	public long getAccount_no() {
		return account_no;
	}

	public void setAccount_no(long account_no) {
		this.account_no = account_no;
	}

	public String getAccount_type() {
		return account_type;
	}

	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account_Info [account_no=" + account_no + ", account_type=" + account_type + ", balance=" + balance
				+ "]";
	}

}
