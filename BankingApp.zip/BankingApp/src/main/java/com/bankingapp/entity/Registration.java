package com.bankingapp.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name="registration")
public class Registration {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int user_id;
	@Column(name="first_name", nullable = false)
	@Pattern(regexp = "^[a-zA-Z]{2,15}$", message = "First Name Should Be Valid")
	private String fname;
	@Column(name="lase_name", nullable = false)
	@Pattern(regexp = "^[a-zA-Z]{2,15}$", message = "Last Name Should Be Valid")
	private String lname;
	@Column(nullable = false, unique = true)
	@Pattern(regexp = "^[a-zA-Z0-9_-]{4,16}$", message = "User Name Should Be Valid")
	private String user_name;
	@Column(nullable = false)
	@Pattern(regexp = "^[a-zA-Z0-9_-]{4,16}$", message = "Password Should Be Valid")
	private String password;
	@Column(nullable = false, unique = true)
	@Pattern(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", message = "Email Should Be Valid")
	private String email_id;
	
	@OneToMany
	@JoinColumn(name="user_id")
	private List<Account_Info> accounts;

	public Registration() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Registration(int user_id, String fname, String lname, String user_name, String password, String email_id) {
		super();
		this.user_id = user_id;
		this.fname = fname;
		this.lname = lname;
		this.user_name = user_name;
		this.password = password;
		this.email_id = email_id;
	}



	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	@Override
	public String toString() {
		return "Registration [user_id=" + user_id + ", fname=" + fname + ", lname=" + lname + ", user_name=" + user_name
				+ ", password=" + password + ", email_id=" + email_id + ", accounts=" + accounts + "]";
	}

	public List<Account_Info> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account_Info> accounts) {
		this.accounts = accounts;
	}
	
}
