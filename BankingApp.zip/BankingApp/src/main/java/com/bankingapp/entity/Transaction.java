package com.bankingapp.entity;

import java.time.LocalDate;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="transaction")
public class Transaction {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long tx_id;
	
	@Column(nullable = false)
	private LocalDate tx_date;
	
	@Column(nullable=false)
	private double tx_amount;
	
	@Column(nullable=false)
	private String tx_type;

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transaction(long tx_id, LocalDate tx_date, double tx_amount, String tx_type) {
		super();
		this.tx_id = tx_id;
		this.tx_date = tx_date;
		this.tx_amount = tx_amount;
		this.tx_type = tx_type;
	}
	
	public Transaction(LocalDate tx_date, double tx_amount, String tx_type) {
		super();
		this.tx_id = tx_id;
		this.tx_date = tx_date;
		this.tx_amount = tx_amount;
		this.tx_type = tx_type;
	}

	public double getTx_amount() {
		return tx_amount;
	}

	public void setTx_amount(double tx_amount) {
		this.tx_amount = tx_amount;
	}

	public long getTx_id() {
		return tx_id;
	}

	public void setTx_id(long tx_id) {
		this.tx_id = tx_id;
	}

	public LocalDate getTx_date() {
		return tx_date;
	}

	public void setTx_date(LocalDate tx_date) {
		this.tx_date = tx_date;
	}

	public String getTx_type() {
		return tx_type;
	}

	public void setTx_type(String tx_type) {
		this.tx_type = tx_type;
	}

	@Override
	public String toString() {
		return "Transaction [tx_id=" + tx_id + ", tx_date=" + tx_date + ", tx_amount=" + tx_amount + ", tx_type="
				+ tx_type + "]";
	}
	
	

}
