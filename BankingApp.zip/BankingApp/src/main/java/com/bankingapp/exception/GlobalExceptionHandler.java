package com.bankingapp.exception;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	@Value(value = "${data.exception.invalidAmount}")
	private String invalidAmountMessage;
	@Value(value = "${data.exception.noSuchCustomer}")
	private String noSuchCustomerMessage;
	@Value(value = "${data.exception.noSuchAccount}")
	private String noSuchAccountMessage;
	
	@Value(value="${data.exception.insufficientFunds}")
	private String insufficientFunds;
	
	@ExceptionHandler(value = InvalidAmountException.class)
	public ResponseEntity<String> invalidAmountException(InvalidAmountException invalidAmountException) {
		return new ResponseEntity<String>(invalidAmountMessage, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(value = NoSuchCustomerException.class)
	public ResponseEntity<String> noSuchCustomerException(NoSuchCustomerException noSuchCustomerException) {
		return new ResponseEntity<String>(noSuchCustomerMessage, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(value = NoSuchAccountException.class)
	public ResponseEntity<String> noSuchAccountException(NoSuchAccountException noSuchAccountException) {
		return new ResponseEntity<String>(noSuchAccountMessage, HttpStatus.NOT_FOUND);
	}

	/*
	 * @ExceptionHandler(value = Exception.class) public ResponseEntity<String>
	 * databaseConnectionFailsException(Exception exception) { return new
	 * ResponseEntity<String>("Internal Server Error",
	 * HttpStatus.INTERNAL_SERVER_ERROR); }
	 */
	
	/*
	 * @ExceptionHandler(value
                      = NoSuchCustomerExistsException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public @ResponseBody ErrorResponse
    handleException(NoSuchCustomerExistsException ex)
    {
        return new ErrorResponse(
            HttpStatus.NOT_FOUND.value(), ex.getMessage());
    }
	 */
	@ExceptionHandler(value = InsufficientFundsException.class)
	public ResponseEntity<String> InsufficientFundsException(InsufficientFundsException insufficientFundsException) {
		return new ResponseEntity<String>(insufficientFunds, HttpStatus.NOT_FOUND);
	}
	
}
