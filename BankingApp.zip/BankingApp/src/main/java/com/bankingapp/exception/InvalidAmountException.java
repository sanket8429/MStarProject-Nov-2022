package com.bankingapp.exception;

public class InvalidAmountException extends RuntimeException {

	private String message;

	public InvalidAmountException(String message) {
		super(message);
		this.message = message;
	}

}
