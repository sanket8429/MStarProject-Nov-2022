package com.bankingapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bankingapp.entity.Account_Info;

@Repository
public interface Account_InfoRepo extends JpaRepository<Account_Info, Long>{

}
