package com.bankingapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bankingapp.entity.Registration;

@Repository
public interface RegistrationRepo extends JpaRepository<Registration, Integer>{

	
	@Query(value= "select email_id from banking_app.registration where email_id=?1",nativeQuery = true)
	public String getEmail(String email);
	
	@Query(value= "select password from banking_app.registration where password=?1",nativeQuery = true)
	public String getPassword(String password);
}
