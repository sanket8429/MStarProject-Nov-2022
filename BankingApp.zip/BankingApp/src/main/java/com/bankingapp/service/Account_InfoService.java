package com.bankingapp.service;

import java.util.List;

import com.bankingapp.entity.Account_Info;

public interface Account_InfoService {
	
	Account_Info createAccount_Info(Account_Info Account_Info);

	void deleteAccount_Info(long id);

	Account_Info getAccount_Info(long id);

	Account_Info updateAccount_Info(Account_Info Account_Info);

	List<Account_Info> getAllAccount_Infos();

}
