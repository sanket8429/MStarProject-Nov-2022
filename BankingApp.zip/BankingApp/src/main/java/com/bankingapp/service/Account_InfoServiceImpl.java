package com.bankingapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankingapp.entity.Account_Info;
import com.bankingapp.exception.NoSuchAccountException;
import com.bankingapp.repository.Account_InfoRepo;

@Service
public class Account_InfoServiceImpl implements Account_InfoService{
	
	@Autowired
	private Account_InfoRepo account_InfoRepo;

	@Override
	public Account_Info createAccount_Info(Account_Info account_info) {
		// TODO Auto-generated method stub
		return account_InfoRepo.save(account_info);
	}

	@Override
	public void deleteAccount_Info(long id) {

		account_InfoRepo.findById(id).orElseThrow(
				() -> new NoSuchAccountException("NO account PRESENT WITH ID = " + id));
		account_InfoRepo.deleteById(id);
	}


	@Override
	public Account_Info getAccount_Info(long id) {

		return account_InfoRepo.findById(id)
				.orElseThrow(() -> new NoSuchAccountException("NO account PRESENT WITH ID = " + id));
	}

	@Override
	public Account_Info updateAccount_Info(Account_Info account_info) {

		Account_Info account = account_InfoRepo.findById(account_info.getAccount_no()).orElseThrow(
				() -> new NoSuchAccountException("NO account PRESENT WITH ID = " + account_info.getAccount_no()));
		
		account.setAccount_type(account_info.getAccount_type());
		account.setBalance(account_info.getBalance());
		return account_InfoRepo.save(account);
		
	}

	@Override
	public List<Account_Info> getAllAccount_Infos() {
		// TODO Auto-generated method stub
		return account_InfoRepo.findAll();
	}

}
