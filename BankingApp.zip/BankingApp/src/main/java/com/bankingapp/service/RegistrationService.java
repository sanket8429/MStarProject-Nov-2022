package com.bankingapp.service;

import java.util.List;
import java.util.Optional;

import com.bankingapp.entity.Registration;

public interface RegistrationService {
	
	public List<Registration> getAllRegistrations();
	
	public Registration getRegistrationById(int id);
	
	public void saveRegistration(Registration registrion);
	
	public void updateRegistration(Registration registrion);
	
	public void deleteRegistration(int id);

	String login(String email, String password);

}
