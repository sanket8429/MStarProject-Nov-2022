package com.bankingapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankingapp.entity.Registration;
import com.bankingapp.exception.NoSuchAccountException;
import com.bankingapp.repository.RegistrationRepo;

import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Service
public class RegistrationServiceImpl implements RegistrationService{
	
	@Autowired
	private RegistrationRepo registrationRepo;
	
	private static Logger logger = LoggerFactory.getLogger(RegistrationServiceImpl.class);

	@Override
	public List<Registration> getAllRegistrations() {
		// TODO Auto-generated method stub
		logger.info("*****\n" + "getAllRegistration Method is Called: ");
		return registrationRepo.findAll();
	}

	@Override
	public Registration getRegistrationById(int id) {
		// TODO Auto-generated method stub
		logger.info("*****\n" + "A getRegistration Method is Called with id: "+id);
		return  registrationRepo.findById(id).orElseThrow(
				()-> new NoSuchAccountException("NO Registration PRESENT WITH ID = " + id));
	}

	@Override
	public void saveRegistration(Registration registrion) {
		
		registrationRepo.save(registrion);
	}
	

	@Override
	public void updateRegistration(Registration registrion) {
		
		int id = registrion.getUser_id();
		Registration reg = registrationRepo.findById(id).get();
		reg.setUser_name(registrion.getUser_name());
		reg.setFname(registrion.getFname());
		reg.setLname(registrion.getLname());
		reg.setPassword(registrion.getPassword());
		reg.setEmail_id(registrion.getEmail_id());
		registrationRepo.save(reg);
	}

	@Override
	@Transactional
	public void deleteRegistration(int id) {

		registrationRepo.deleteById(id);
	}
	
	@Override
	public String login(String email, String password) {
		if (email.equals(registrationRepo.getEmail(email)) && password.equals(registrationRepo.getPassword(password))) {
			logger.info("*****\n" + "Customer logged in with email-id: "+email);			
			return "Login Succesfull";
		}

		return "Login failed";
		
		
	}

}
