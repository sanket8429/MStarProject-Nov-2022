package com.bankingapp.service;

import java.util.List;

import com.bankingapp.entity.Transaction;
import com.bankingapp.exception.InsufficientFundsException;

public interface TransactionService {
	
	Transaction createTransaction(Transaction Transaction);

	void deleteTransaction(long id);

	Transaction getTransactionsForAccount(long accountId);

	Transaction getTransaction(long transactionId);

	Transaction updateTransaction(Transaction Transaction);

	List<Transaction> getAllTransactions();
	
	void debit(long account_number, double amount) throws InsufficientFundsException;

	void credit(long account_number, double amount, String tx_type);

}
