package com.bankingapp.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;

import com.bankingapp.entity.Registration;
import com.bankingapp.repository.RegistrationRepo;
import com.bankingapp.repository.RegistrationRepo;

@SpringBootTest(classes= {MockitoServiceTestForTestingRegistrationRepoFindAllMethod.class})
public class MockitoServiceTestForTestingRegistrationRepoFindAllMethod {

	@Mock
	RegistrationRepo registrationRepository;
	
	@InjectMocks
	RegistrationService registrationService;
	
	//public List<Registration> register;
	
	@Test
	@Order(1)
	public void test_getAllRegistration() {
		
		List<Registration> register = new ArrayList<>();
		
		register.add(new Registration(1001, "akash", "jadhao", "apj123","apj@123","apj123@gmail.com"));
		register.add(new Registration(1002, "sanket", "wankhede", "sanket123", "snk@123", "snk123@gmail.com"));
		register.add(new Registration(1003, "harshada", "madghut", "harshada123", "hrsd@123", "hrsh123@gmail.com"));
		register.add(new Registration(1004, "pradnesh", "jadhav","pjadhav123", "pradna@123", "pradnesh123@gmail.com"));
		when(registrationRepository.findAll()).thenReturn(register);
		
		//public Registration(int user_id, String fname, String lname, String user_name, String password, String email_id)
		//Assertions.assertEquals(1,registrationService.getAllRegistrations().size());
		Assertions.assertEquals(4,registrationService.getAllRegistrations().size());
		
	}
}
